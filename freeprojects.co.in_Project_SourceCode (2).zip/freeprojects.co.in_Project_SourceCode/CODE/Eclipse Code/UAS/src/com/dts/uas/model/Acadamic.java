package com.dts.uas.model;

public class Acadamic {

	private String loginname;
	private String sscreg;
	private String ugreg;
	private String greg;
	private String yearofpass1;
	private double percentage1;
	private double percentage2;
	private double percentage3;
	private String yearofpass2;
	private String yearofpass3;
	private String course;
	private String discipline;
	public String regno;
	private String subject;
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getRegno()
	{
		return regno;
	}
	public void setRegno(String s)
	{
		regno=s;
	}
	
	public String getLoginname() {
		return loginname;
	}
	
	public void setLoginname(String loginname) {
		this.loginname = loginname;
	}
	
	public String getYearofpass1() {
		return yearofpass1;
	}
	
	public void setYearofpass1(String yearofpass1) {
		this.yearofpass1 = yearofpass1;
	}
	
	public double getPercentage1() {
		return percentage1;
	}
	public void setPercentage1(double percentage1) {
		this.percentage1 = percentage1;
	}
	public double getPercentage2() {
		return percentage2;
	}
	public void setPercentage2(double percentage2) {
		this.percentage2 = percentage2;
	}
	public double getPercentage3() {
		return percentage3;
	}
	public void setPercentage3(double percentage3) {
		this.percentage3 = percentage3;
	}
	public String getYearofpass2() {
		return yearofpass2;
	}
	public void setYearofpass2(String yearofpass2) {
		this.yearofpass2 = yearofpass2;
	}
	public String getYearofpass3() {
		return yearofpass3;
	}
	public void setYearofpass3(String yearofpass3) {
		this.yearofpass3 = yearofpass3;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getDiscipline() {
		return discipline;
	}
	public void setDiscipline(String discipline) {
		this.discipline = discipline;
	}
	public String getSscreg() {
		return sscreg;
	}
	public void setSscreg(String sscreg) {
		this.sscreg = sscreg;
	}
	public String getUgreg() {
		return ugreg;
	}
	public void setUgreg(String ugreg) {
		this.ugreg = ugreg;
	}
	public String getGreg() {
		return greg;
	}
	public void setGreg(String greg) {
		this.greg = greg;
	}
}
