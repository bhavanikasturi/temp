package com.capgemini.mobipur.exception;

public class MobilePurchaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7290476975593304142L;
	/**
	 * 
	 */
	public MobilePurchaseException(){
		super();
	}
	public MobilePurchaseException(String message) {
		super(message);
		
	}

}
